package MetroComponents;
public class MetroCalendar extends MetroComponent
{
    public MetroCalendar()
    {
        controlContent.append("<div data-role=\"calendar\"></div>");
    }
}
