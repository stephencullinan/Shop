package MetroComponents;
public class MetroPreLoader extends MetroComponent 
{
    public MetroPreLoader()
    {
        controlContent.append("<div data-role=\"preloader\" data-type=\"cycle\" data-style=\"color\"></div>");
    }
}
